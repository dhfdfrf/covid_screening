from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Sequence, Tuple

import torch.nn as nn


@dataclass(frozen=True)
class ModelBuildConfig:
    name: str
    in_channels: int = 1
    out_channels: int = 1
    image_size: Optional[Tuple[int, int]] = None
    return_features: bool = False


def available_models() -> Sequence[str]:
    return ("transunet2d", "swin_unet2d", "uctransnet2d")


_ALIASES: Dict[str, str] = {
    "transunet": "transunet2d",
    "swin-unet": "swin_unet2d",
    "swinunet": "swin_unet2d",
    "uctransnet": "uctransnet2d",
}


def build_model(cfg: ModelBuildConfig) -> nn.Module:
    name = _ALIASES.get(cfg.name.strip().lower(), cfg.name.strip().lower())
    if name == "transunet2d":
        from src.models.transunet2d import build_transunet2d
        return build_transunet2d(cfg.in_channels, cfg.out_channels, return_features=cfg.return_features)
    if name == "swin_unet2d":
        from src.models.swin_unet2d import build_swin_unet2d
        return build_swin_unet2d(cfg.in_channels, cfg.out_channels, image_size=cfg.image_size, return_features=cfg.return_features)
    if name == "uctransnet2d":
        from src.models.uctransnet2d import build_uctransnet2d
        return build_uctransnet2d(cfg.in_channels, cfg.out_channels, return_features=cfg.return_features)
    raise ValueError(f"Unknown model name: {cfg.name}. Available: {', '.join(available_models())}")
