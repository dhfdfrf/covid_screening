from __future__ import annotations

from pathlib import Path
from typing import Callable, Optional, Tuple

import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset


IMG_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


def _load_grayscale(path: Path) -> np.ndarray:
    img = Image.open(path).convert("L")
    return np.asarray(img, dtype=np.float32)


class QaTaCOV19Dataset(Dataset):
    def __init__(
        self,
        image_dir: str,
        mask_dir: str,
        image_size: Tuple[int, int] = (224, 224),
        normalize: bool = True,
        transform: Optional[Callable] = None,
    ):
        self.image_dir = Path(image_dir)
        self.mask_dir = Path(mask_dir)
        self.image_size = image_size
        self.normalize = normalize
        self.transform = transform
        self.samples = []
        for p in sorted(self.image_dir.iterdir()):
            if p.suffix.lower() not in IMG_EXTS:
                continue
            mp = self.mask_dir / p.name
            if mp.exists():
                self.samples.append((p, mp))
        if not self.samples:
            raise RuntimeError(f"No matched image-mask pairs found in {image_dir} and {mask_dir}")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx: int):
        img_path, mask_path = self.samples[idx]
        image = Image.fromarray(_load_grayscale(img_path)).resize(self.image_size, Image.BILINEAR)
        mask = Image.fromarray(_load_grayscale(mask_path)).resize(self.image_size, Image.NEAREST)

        image = np.asarray(image, dtype=np.float32)
        mask = np.asarray(mask, dtype=np.float32)

        if self.normalize:
            image = image / 255.0
        mask = (mask > 127).astype(np.float32)

        image = torch.from_numpy(image).unsqueeze(0)
        mask = torch.from_numpy(mask).unsqueeze(0)

        if self.transform is not None:
            image, mask = self.transform(image, mask)

        return {
            "image": image,
            "mask": mask,
            "id": img_path.stem,
        }
